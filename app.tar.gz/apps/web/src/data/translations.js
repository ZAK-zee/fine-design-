
export const translations = {
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      portfolio: 'Portfolio',
      contact: 'Contact'
    },
    hero: {
      tagline: 'Design • Build • Better Futures',
      subtitle: 'Transforming spaces into exceptional experiences through innovative design and superior craftsmanship',
      cta: 'Explore Our Work',
      scrollIndicator: 'Scroll to discover'
    },
    about: {
      title: 'About Fine Design',
      subtitle: 'Building excellence since 2015',
      story: 'Fine Design is a premier construction and interior design firm dedicated to creating spaces that inspire. With over 8 years of experience, we blend innovative design with meticulous execution to deliver projects that exceed expectations.',
      mission: 'Our mission is to transform visions into reality through exceptional design, quality craftsmanship, and unwavering commitment to client satisfaction.',
      valuesTitle: 'Our Core Values',
      values: {
        quality: {
          title: 'Quality',
          description: 'We never compromise on materials or workmanship'
        },
        experience: {
          title: 'Experience',
          description: '8+ years of proven expertise in design and construction'
        },
        delivery: {
          title: 'On-Time Delivery',
          description: 'We respect deadlines and deliver projects as promised'
        },
        trust: {
          title: 'Trusted Teams',
          description: 'Skilled professionals committed to excellence'
        }
      },
      teamTitle: 'Meet Our Team',
      team: [
        {
          name: 'Khalid Al-Mansour',
          role: 'Founder & CEO',
          bio: 'Visionary leader with 12 years in construction and design'
        },
        {
          name: 'Fatima Hassan',
          role: 'Lead Interior Designer',
          bio: 'Award-winning designer specializing in luxury interiors'
        },
        {
          name: 'Omar Rashid',
          role: 'Project Manager',
          bio: 'Expert in delivering complex projects on time and budget'
        }
      ]
    },
    services: {
      title: 'Our Services',
      subtitle: 'Comprehensive solutions for every project',
      items: [
        {
          title: 'Interior Design',
          description: 'Create stunning, functional spaces that reflect your vision and lifestyle with our expert interior design services.',
          features: ['Space Planning', 'Custom Furniture', '3D Visualization', 'Material Selection']
        },
        {
          title: 'Renovation',
          description: 'Transform existing spaces with our comprehensive renovation services, breathing new life into your property.',
          features: ['Complete Remodeling', 'Kitchen & Bath', 'Structural Updates', 'Modern Upgrades']
        },
        {
          title: 'Outfitting & Fit-out',
          description: 'Professional fit-out services for commercial and residential spaces, from concept to completion.',
          features: ['Office Fit-out', 'Retail Spaces', 'Hospitality', 'Turnkey Solutions']
        },
        {
          title: 'Civil Works',
          description: 'Expert civil engineering and construction services for projects of all scales and complexities.',
          features: ['Foundation Work', 'Structural Building', 'Site Development', 'Infrastructure']
        },
        {
          title: 'Air Conditioning / HVAC',
          description: 'Advanced HVAC solutions ensuring optimal climate control and energy efficiency for your space.',
          features: ['System Design', 'Installation', 'Maintenance', 'Energy Optimization']
        },
        {
          title: 'Civil Protection & Fire Protection',
          description: 'Comprehensive fire safety and civil protection systems to safeguard your property and occupants.',
          features: ['Fire Alarm Systems', 'Sprinkler Installation', 'Safety Compliance', 'Emergency Systems']
        }
      ]
    },
    portfolio: {
      title: 'Our Portfolio',
      subtitle: 'Showcasing our finest work',
      filterAll: 'All Projects',
      categories: {
        interior: 'Interior Design',
        renovation: 'Renovation',
        outfitting: 'Outfitting',
        civil: 'Civil Works',
        hvac: 'HVAC',
        fire: 'Fire Protection'
      }
    },
    contact: {
      title: 'Get In Touch',
      subtitle: 'Let\'s discuss your next project',
      form: {
        name: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        message: 'Your Message',
        submit: 'Send Message',
        sending: 'Sending...',
        success: 'Message sent successfully',
        error: 'Failed to send message'
      },
      info: {
        title: 'Contact Information',
        address: 'Dubai, United Arab Emirates',
        phone: '+971 50 123 4567',
        email: 'info@finedesign.ae',
        hours: 'Sun - Thu: 9:00 AM - 6:00 PM'
      }
    },
    testimonials: {
      title: 'What Our Clients Say',
      items: [
        {
          text: 'Fine Design transformed our office space beyond our expectations. The attention to detail and professionalism was outstanding.',
          author: 'Sarah Al-Khouri',
          role: 'CEO, Tech Innovations',
          rating: 5
        },
        {
          text: 'The renovation of our villa was completed on time and within budget. The team was professional and the quality exceptional.',
          author: 'Ahmed Bin Rashid',
          role: 'Private Client',
          rating: 5
        },
        {
          text: 'Their interior design expertise helped us create a showroom that perfectly represents our brand. Highly recommended.',
          author: 'Layla Mansour',
          role: 'Retail Director',
          rating: 5
        }
      ]
    },
    footer: {
      tagline: 'Design • Build • Better Futures',
      copyright: '© 2026 Fine Design. All rights reserved.',
      links: {
        privacy: 'Privacy Policy',
        terms: 'Terms of Service'
      }
    }
  },
  ar: {
    nav: {
      home: 'الرئيسية',
      about: 'من نحن',
      services: 'خدماتنا',
      portfolio: 'أعمالنا',
      contact: 'اتصل بنا'
    },
    hero: {
      tagline: 'تصميم • بناء • مستقبل أفضل',
      subtitle: 'نحول المساحات إلى تجارب استثنائية من خلال التصميم المبتكر والحرفية المتميزة',
      cta: 'استكشف أعمالنا',
      scrollIndicator: 'مرر للاكتشاف'
    },
    about: {
      title: 'عن فاين ديزاين',
      subtitle: 'نبني التميز منذ 2015',
      story: 'فاين ديزاين هي شركة رائدة في البناء والتصميم الداخلي مكرسة لإنشاء مساحات ملهمة. مع أكثر من 8 سنوات من الخبرة، نمزج التصميم المبتكر مع التنفيذ الدقيق لتقديم مشاريع تتجاوز التوقعات.',
      mission: 'مهمتنا هي تحويل الرؤى إلى واقع من خلال التصميم الاستثنائي والحرفية عالية الجودة والالتزام الثابت برضا العملاء.',
      valuesTitle: 'قيمنا الأساسية',
      values: {
        quality: {
          title: 'الجودة',
          description: 'لا نتنازل أبداً عن المواد أو الصنعة'
        },
        experience: {
          title: 'الخبرة',
          description: 'أكثر من 8 سنوات من الخبرة المثبتة في التصميم والبناء'
        },
        delivery: {
          title: 'التسليم في الوقت المحدد',
          description: 'نحترم المواعيد النهائية ونسلم المشاريع كما وعدنا'
        },
        trust: {
          title: 'فرق موثوقة',
          description: 'محترفون ماهرون ملتزمون بالتميز'
        }
      },
      teamTitle: 'تعرف على فريقنا',
      team: [
        {
          name: 'خالد المنصور',
          role: 'المؤسس والرئيس التنفيذي',
          bio: 'قائد صاحب رؤية مع 12 عاماً في البناء والتصميم'
        },
        {
          name: 'فاطمة حسن',
          role: 'مصممة داخلية رئيسية',
          bio: 'مصممة حائزة على جوائز متخصصة في التصميمات الفاخرة'
        },
        {
          name: 'عمر رشيد',
          role: 'مدير المشاريع',
          bio: 'خبير في تسليم المشاريع المعقدة في الوقت المحدد والميزانية'
        }
      ]
    },
    services: {
      title: 'خدماتنا',
      subtitle: 'حلول شاملة لكل مشروع',
      items: [
        {
          title: 'التصميم الداخلي',
          description: 'أنشئ مساحات مذهلة وعملية تعكس رؤيتك وأسلوب حياتك مع خدمات التصميم الداخلي الخبيرة لدينا.',
          features: ['تخطيط المساحات', 'أثاث مخصص', 'تصور ثلاثي الأبعاد', 'اختيار المواد']
        },
        {
          title: 'التجديد',
          description: 'حول المساحات الموجودة مع خدمات التجديد الشاملة لدينا، مما يبث حياة جديدة في ممتلكاتك.',
          features: ['إعادة تصميم كاملة', 'المطبخ والحمام', 'تحديثات هيكلية', 'ترقيات حديثة']
        },
        {
          title: 'التجهيز والتشطيب',
          description: 'خدمات تشطيب احترافية للمساحات التجارية والسكنية، من المفهوم إلى الإنجاز.',
          features: ['تشطيب المكاتب', 'المساحات التجارية', 'الضيافة', 'حلول متكاملة']
        },
        {
          title: 'الأعمال المدنية',
          description: 'خدمات هندسة مدنية وبناء خبيرة للمشاريع من جميع الأحجام والتعقيدات.',
          features: ['أعمال الأساسات', 'البناء الهيكلي', 'تطوير الموقع', 'البنية التحتية']
        },
        {
          title: 'تكييف الهواء / التدفئة والتهوية',
          description: 'حلول متقدمة للتدفئة والتهوية وتكييف الهواء تضمن التحكم الأمثل في المناخ وكفاءة الطاقة لمساحتك.',
          features: ['تصميم النظام', 'التركيب', 'الصيانة', 'تحسين الطاقة']
        },
        {
          title: 'الحماية المدنية والحماية من الحرائق',
          description: 'أنظمة شاملة للسلامة من الحرائق والحماية المدنية لحماية ممتلكاتك وشاغليها.',
          features: ['أنظمة إنذار الحريق', 'تركيب الرشاشات', 'الامتثال للسلامة', 'أنظمة الطوارئ']
        }
      ]
    },
    portfolio: {
      title: 'أعمالنا',
      subtitle: 'عرض أفضل أعمالنا',
      filterAll: 'جميع المشاريع',
      categories: {
        interior: 'التصميم الداخلي',
        renovation: 'التجديد',
        outfitting: 'التجهيز',
        civil: 'الأعمال المدنية',
        hvac: 'التدفئة والتهوية',
        fire: 'الحماية من الحرائق'
      }
    },
    contact: {
      title: 'تواصل معنا',
      subtitle: 'لنناقش مشروعك القادم',
      form: {
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        message: 'رسالتك',
        submit: 'إرسال الرسالة',
        sending: 'جاري الإرسال...',
        success: 'تم إرسال الرسالة بنجاح',
        error: 'فشل إرسال الرسالة'
      },
      info: {
        title: 'معلومات الاتصال',
        address: 'دبي، الإمارات العربية المتحدة',
        phone: '+971 50 123 4567',
        email: 'info@finedesign.ae',
        hours: 'الأحد - الخميس: 9:00 صباحاً - 6:00 مساءً'
      }
    },
    testimonials: {
      title: 'ماذا يقول عملاؤنا',
      items: [
        {
          text: 'حولت فاين ديزاين مساحة مكتبنا بما يتجاوز توقعاتنا. كان الاهتمام بالتفاصيل والاحترافية متميزين.',
          author: 'سارة الخوري',
          role: 'الرئيس التنفيذي، ابتكارات التكنولوجيا',
          rating: 5
        },
        {
          text: 'تم الانتهاء من تجديد فيلتنا في الوقت المحدد وضمن الميزانية. كان الفريق محترفاً والجودة استثنائية.',
          author: 'أحمد بن راشد',
          role: 'عميل خاص',
          rating: 5
        },
        {
          text: 'ساعدتنا خبرتهم في التصميم الداخلي على إنشاء صالة عرض تمثل علامتنا التجارية بشكل مثالي. موصى به بشدة.',
          author: 'ليلى منصور',
          role: 'مديرة التجزئة',
          rating: 5
        }
      ]
    },
    footer: {
      tagline: 'تصميم • بناء • مستقبل أفضل',
      copyright: '© 2026 فاين ديزاين. جميع الحقوق محفوظة.',
      links: {
        privacy: 'سياسة الخصوصية',
        terms: 'شروط الخدمة'
      }
    }
  }
};
