
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext.jsx';
import { translations } from '@/data/translations.js';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const ContactPage = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise(resolve => setTimeout(resolve, 1500));

    toast.success(t.contact.form.success);
    setFormData({ name: '', email: '', phone: '', message: '' });
    setIsSubmitting(false);
  };

  const contactInfo = [
    {
      icon: MapPin,
      label: t.contact.info.address,
      value: t.contact.info.address
    },
    {
      icon: Phone,
      label: t.contact.info.phone,
      value: t.contact.info.phone
    },
    {
      icon: Mail,
      label: t.contact.info.email,
      value: t.contact.info.email
    },
    {
      icon: Clock,
      label: t.contact.info.hours,
      value: t.contact.info.hours
    }
  ];

  return (
    <>
      <Helmet>
        <title>{`${t.contact.title} - Fine Design`}</title>
        <meta
          name="description"
          content="Contact Fine Design for your construction and interior design needs. Get in touch with our expert team in Dubai."
        />
      </Helmet>

      <Header />

      <main className="pt-20 bg-background">
        <section className="py-24 bg-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="mb-4 text-foreground">{t.contact.title}</h1>
              <p className="text-xl text-muted-foreground">
                {t.contact.subtitle}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="bg-card border border-border rounded-2xl p-8 mb-8 shadow-sm">
                  <h2 className="text-2xl font-semibold mb-6 text-foreground">
                    {t.contact.info.title}
                  </h2>
                  <div className="space-y-6">
                    {contactInfo.map((info, index) => (
                      <div key={index} className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                          <info.icon className="w-6 h-6 text-gold" />
                        </div>
                        <div>
                          <p className="font-medium mb-1 text-foreground">{info.label}</p>
                          <p className="text-muted-foreground">{info.value}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <form onSubmit={handleSubmit} className="space-y-6 bg-card p-8 rounded-2xl border border-border shadow-sm">
                  <div>
                    <Label htmlFor="name" className="text-foreground">{t.contact.form.name}</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="mt-2 bg-input text-foreground placeholder:text-muted-foreground focus-visible:ring-gold"
                      placeholder={t.contact.form.name}
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-foreground">{t.contact.form.email}</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-2 bg-input text-foreground placeholder:text-muted-foreground focus-visible:ring-gold"
                      placeholder={t.contact.form.email}
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-foreground">{t.contact.form.phone}</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="mt-2 bg-input text-foreground placeholder:text-muted-foreground focus-visible:ring-gold"
                      placeholder={t.contact.form.phone}
                    />
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-foreground">{t.contact.form.message}</Label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      rows={6}
                      value={formData.message}
                      onChange={handleChange}
                      className="mt-2 bg-input text-foreground placeholder:text-muted-foreground resize-none focus-visible:ring-gold"
                      placeholder={t.contact.form.message}
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gold text-white hover:bg-primary transition-colors duration-300 font-semibold"
                  >
                    {isSubmitting ? t.contact.form.sending : t.contact.form.submit}
                  </Button>
                </form>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContactPage;
