
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext.jsx';
import { translations } from '@/data/translations.js';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import FilterBar from '@/components/FilterBar.jsx';
import PortfolioCard from '@/components/PortfolioCard.jsx';

const PortfolioPage = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const [activeFilter, setActiveFilter] = useState('all');

  const portfolioItems = [
    {
      image: 'https://images.unsplash.com/photo-1633348571807-b823606c473d',
      title: 'Luxury Villa Interior',
      category: 'interior'
    },
    {
      image: 'https://images.unsplash.com/photo-1651485637937-4b38ee131e3f',
      title: 'Modern Living Space',
      category: 'interior'
    },
    {
      image: 'https://images.unsplash.com/photo-1563191848-b01d0258f1f9',
      title: 'Contemporary Office Design',
      category: 'interior'
    },
    {
      image: 'https://images.unsplash.com/photo-1634967389630-b6bbab0fab7e',
      title: 'Complete Home Renovation',
      category: 'renovation'
    },
    {
      image: 'https://images.unsplash.com/photo-1688420327180-fada094d7ba1',
      title: 'Kitchen Remodel',
      category: 'renovation'
    },
    {
      image: 'https://images.unsplash.com/photo-1702450899637-a3c160a52916',
      title: 'Bathroom Upgrade',
      category: 'renovation'
    },
    {
      image: 'https://images.unsplash.com/photo-1527699394565-4be926d174de',
      title: 'Heritage Building Restoration',
      category: 'renovation'
    },
    {
      image: 'https://images.unsplash.com/photo-1601059534303-e29a69eaa8ce',
      title: 'Commercial Building Construction',
      category: 'civil'
    },
    {
      image: 'https://images.unsplash.com/photo-1616906065110-daacbce0286d',
      title: 'Infrastructure Development',
      category: 'civil'
    },
    {
      image: 'https://images.unsplash.com/photo-1688313899343-0e591ae61875',
      title: 'Foundation & Structural Work',
      category: 'civil'
    },
    {
      image: 'https://images.unsplash.com/photo-1511695622093-c9c94b8674a5',
      title: 'Central HVAC System',
      category: 'hvac'
    },
    {
      image: 'https://images.unsplash.com/photo-1513257805917-a0da1146eb15',
      title: 'Commercial Cooling Solution',
      category: 'hvac'
    },
    {
      image: 'https://images.unsplash.com/photo-1537439202547-14268a62c020',
      title: 'Energy-Efficient Climate Control',
      category: 'hvac'
    },
    {
      image: 'https://images.unsplash.com/photo-1666185761937-67f14ed3cae7',
      title: 'Fire Alarm System Installation',
      category: 'fire'
    },
    {
      image: 'https://images.unsplash.com/photo-1671627473787-3f90197392fe',
      title: 'Sprinkler System Integration',
      category: 'fire'
    }
  ];

  const filteredItems = activeFilter === 'all'
    ? portfolioItems
    : portfolioItems.filter(item => item.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>{`${t.portfolio.title} - Fine Design`}</title>
        <meta
          name="description"
          content="Browse Fine Design's portfolio of completed projects including interior design, renovation, civil works, HVAC, and fire protection installations."
        />
      </Helmet>

      <Header />

      <main className="pt-20 bg-background">
        <section className="py-24 bg-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="mb-4 text-foreground">{t.portfolio.title}</h1>
              <p className="text-xl text-muted-foreground">
                {t.portfolio.subtitle}
              </p>
            </motion.div>

            <FilterBar
              categories={t.portfolio.categories}
              activeFilter={activeFilter}
              onFilterChange={setActiveFilter}
              translations={t.portfolio}
            />

            <motion.div
              layout
              className="columns-1 md:columns-2 lg:columns-3 gap-6"
            >
              {filteredItems.map((item, index) => (
                <PortfolioCard
                  key={`${item.category}-${index}`}
                  {...item}
                  category={t.portfolio.categories[item.category]}
                />
              ))}
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default PortfolioPage;
