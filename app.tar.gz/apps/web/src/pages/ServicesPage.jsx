
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext.jsx';
import { translations } from '@/data/translations.js';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';

const ServicesPage = () => {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <>
      <Helmet>
        <title>{`${t.services.title} - Fine Design`}</title>
        <meta
          name="description"
          content="Explore Fine Design's comprehensive services: Interior Design, Renovation, Fit-out, Civil Works, HVAC, and Fire Protection systems."
        />
      </Helmet>

      <Header />

      <main className="pt-20 bg-background">
        <section className="py-24 bg-gradient-to-b from-background to-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="mb-4 text-foreground">{t.services.title}</h1>
              <p className="text-xl text-muted-foreground">
                {t.services.subtitle}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {t.services.items.map((service, index) => (
                <ServiceCard
                  key={index}
                  {...service}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ServicesPage;
