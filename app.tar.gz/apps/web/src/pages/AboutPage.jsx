
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext.jsx';
import { translations } from '@/data/translations.js';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ValueIcon from '@/components/ValueIcon.jsx';
import TeamMember from '@/components/TeamMember.jsx';

const AboutPage = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const values = [
    { type: 'quality', ...t.about.values.quality },
    { type: 'experience', ...t.about.values.experience },
    { type: 'delivery', ...t.about.values.delivery },
    { type: 'trust', ...t.about.values.trust }
  ];

  return (
    <>
      <Helmet>
        <title>{`${t.about.title} - Fine Design`}</title>
        <meta
          name="description"
          content="Learn about Fine Design's mission, values, and expert team. Building excellence in construction and interior design since 2015."
        />
      </Helmet>

      <Header />

      <main className="pt-20 bg-background">
        <section className="py-24 bg-gradient-to-b from-background to-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="mb-4 text-foreground">{t.about.title}</h1>
              <p className="text-xl text-gold font-medium">
                {t.about.subtitle}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-24">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <p className="text-lg leading-relaxed mb-6 text-foreground">
                  {t.about.story}
                </p>
                <p className="text-lg leading-relaxed text-muted-foreground">
                  {t.about.mission}
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative aspect-square rounded-2xl overflow-hidden bg-secondary shadow-xl shadow-foreground/5"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-gold/10 to-transparent z-10" />
                <img
                  src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c"
                  alt="Fine Design Office"
                  className="w-full h-full object-cover"
                />
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="mb-4 text-foreground">{t.about.valuesTitle}</h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
              {values.map((value, index) => (
                <ValueIcon
                  key={value.type}
                  {...value}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-secondary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="mb-4 text-foreground">{t.about.teamTitle}</h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {t.about.team.map((member, index) => (
                <TeamMember
                  key={index}
                  {...member}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default AboutPage;
